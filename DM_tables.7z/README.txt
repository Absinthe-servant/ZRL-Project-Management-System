请将上述文件放到达梦数据库的项目目录下
（默认为：C:\dmdbms\projects）