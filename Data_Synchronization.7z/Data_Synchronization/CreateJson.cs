using System;
using System.Collections.Generic;
using System.Data;
using Newtonsoft.Json;

namespace ZRL_Employee_Info_Sys.Helpers
{
    public static class CreateJson
    {
        public static string ToJson(DataTable dt)
        {
            return JsonConvert.SerializeObject(ToList(dt));
        }

        public static string ToJson(Dictionary<string, object> dict)
        {
            return JsonConvert.SerializeObject(dict);
        }

        public static List<Dictionary<string, object>> ToList(DataTable dt)
        {
            var list = new List<Dictionary<string, object>>();
            if (dt == null) return list;

            foreach (DataRow row in dt.Rows)
            {
                var dict = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                foreach (DataColumn col in dt.Columns)
                {
                    var value = row[col];
                    dict[col.ColumnName] = value == DBNull.Value ? null : value;
                }
                list.Add(dict);
            }
            return list;
        }

        public static Dictionary<string, object> ToObject(DataRow row)
        {
            var dict = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            if (row == null) return dict;

            var table = row.Table;
            foreach (DataColumn col in table.Columns)
            {
                var value = row[col];
                dict[col.ColumnName] = value == DBNull.Value ? null : value;
            }
            return dict;
        }
    }
}
