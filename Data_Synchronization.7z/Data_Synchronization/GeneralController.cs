﻿using System.Text;
using System.Xml.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.IO;
using Microsoft.Extensions.Configuration;

namespace ZRL_Employee_Info_Sys.Controllers
{
    [Route("[controller]")]
    public class GeneralController : Controller
    {
        public IConfiguration _configuration { get; set; }
        private readonly IWebHostEnvironment _env;

        public GeneralController(IConfiguration configuration, IWebHostEnvironment env)
        {
            _configuration = configuration;
            _env = env;
        }

        [HttpGet("readMenu")]
        public IActionResult readMenu()
        {
            // 使用 IWebHostEnvironment 正确定位 webroot（避免依赖 Directory.GetCurrentDirectory）
            var webRoot = _env.WebRootPath ?? Path.Combine(_env.ContentRootPath, "wwwroot");
            var filePath = Path.Combine(webRoot, "tree.xml");

            if (!System.IO.File.Exists(filePath))
            {
                // 更明确的错误信息，便于诊断：文件可能未复制到输出目录或 webroot 路径不正确
                return NotFound(new { message = "tree.xml not found", path = filePath });
            }

            try
            {
                string content = System.IO.File.ReadAllText(filePath, Encoding.UTF8);
                XDocument xDoc = XDocument.Parse(content);
                JObject json = JObject.FromObject(xDoc);
                string transformed = json.ToString().Replace("MenuItem", "children").Replace("@", "");

                int start = transformed.IndexOf('[');
                int end = transformed.LastIndexOf(']');
                if (start < 0 || end < 0 || end <= start)
                {
                    return BadRequest(new { message = "XML->JSON conversion did not produce an array" });
                }

                string result = transformed[start..(end + 1)];
                return Content(result, "application/json; charset=utf-8");
            }
            catch (System.Exception ex)
            {
                // 捕获并返回可供调试的异常信息（生产环境可改为记录日志）
                return Problem(detail: ex.Message);
            }
        }

        // 诊断端点：返回运行时路径信息和 index.html 是否存在
        [HttpGet("debug/paths")]
        public IActionResult DebugPaths()
        {
            var contentRoot = _env.ContentRootPath;
            var webRoot = _env.WebRootPath ?? Path.Combine(contentRoot, "wwwroot");
            var currentDir = Directory.GetCurrentDirectory();
            var indexPath = Path.Combine(webRoot, "index.html");
            var indexExists = System.IO.File.Exists(indexPath);
            return Json(new
            {
                ContentRoot = contentRoot,
                WebRoot = webRoot,
                CurrentDirectory = currentDir,
                IndexPath = indexPath,
                IndexExists = indexExists,
                IndexLastWrite = indexExists ? System.IO.File.GetLastWriteTimeUtc(indexPath).ToString("o") : null
            });
        }

        // 可选：直接返回 index.html 内容以便比对
        [HttpGet("debug/index")]
        public IActionResult DebugIndex()
        {
            var webRoot = _env.WebRootPath ?? Path.Combine(_env.ContentRootPath, "wwwroot");
            var indexPath = Path.Combine(webRoot, "index.html");
            if (!System.IO.File.Exists(indexPath)) return NotFound("index.html not found at: " + indexPath);
            var content = System.IO.File.ReadAllText(indexPath, Encoding.UTF8);
            return Content(content, "text/html; charset=utf-8");
        }

        //文件读取
        [HttpGet("getCfg")]
        public string GetCfg(string v_FileName)
        {
            if (v_FileName == "tree.xml")
                v_FileName = "wwwroot\\tree.xml";
            using (StreamReader reader = new StreamReader(v_FileName, Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }

        //文件写入
        [HttpPost("writeFile")]
        public void WriteTolFile([FromForm] string v_Content, [FromForm] string v_FileName)
        // [FromForm] + string + v_Content ---> 参数来源 + 参数类型 + 参数名
        {

            using (StreamWriter writer = new StreamWriter(v_FileName))
            {
                writer.WriteLine(v_Content);
            }
        }

        //读取配置文件appsettings.json中的配置信息
        [HttpGet]
        [Route("readConfig")]
        public string ReadConfig()
        {
            //读取配置文件appsettings中的配置内容。以下两种方式均可
            //var DbConn = _configuration["ConnectionStrings:DmConn"];
            var versionInfo = _configuration.GetValue<string>("Setting:AppName") + "  " + _configuration.GetValue<string>("Setting:Version");
            return versionInfo;
        }

        [HttpGet("getAccount")]
        public IActionResult GetAccount()
        {
            var user = HttpContext.User;
            if (user?.Identity?.IsAuthenticated == true)
            {
                var name = user.Identity?.Name ?? "";
                var claims = user.Claims.ToDictionary(c => c.Type, c => c.Value);
                return Json(new { authenticated = true, name, claims });
            }
            return Json(new { authenticated = false });
        }
    }
}
