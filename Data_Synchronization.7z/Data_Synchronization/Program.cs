using ZRL_Employee_Info_Sys.Helpers;

var builder = WebApplication.CreateBuilder(args);
string strConn = builder.Configuration.GetConnectionString("DmConn") + "";
DBHelper.Conn = strConn;
builder.Services.AddControllers();

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();
app.MapControllers();
app.Run();