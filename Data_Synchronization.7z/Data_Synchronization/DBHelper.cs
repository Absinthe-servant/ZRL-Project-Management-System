using System;
using System.Data;
using Dm;

namespace ZRL_Employee_Info_Sys.Helpers
{
    public static class DBHelper
    {
        private static DmConnection _connection;
        public static string Conn
        {
            set
            {
                _connection = new DmConnection(value);
            }
        }

        public static DataSet Query(string strSQL)
        {
            DataSet ds = new DataSet();
            try
            {
                if (_connection.State != ConnectionState.Open)
                {
                    _connection.Open();
                }

                DmDataAdapter adapter = new DmDataAdapter(strSQL, _connection);
                adapter.Fill(ds);
            }
            catch (Exception ex)
            {
                throw new Exception("数据库查询失败: " + ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
            }

            return ds;
        }

        public static int ExecuteNonQuery(string strSQL)
        {
            int result = 0;
            try
            {
                if (_connection.State != ConnectionState.Open)
                {
                    _connection.Open();
                }

                DmCommand command = new DmCommand(strSQL, _connection);
                result = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("数据库操作失败: " + ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
            }

            return result;
        }

        internal static object ExecuteScalar(string strSQL)
        {
            object result = null;
            try
            {
                if (_connection.State != ConnectionState.Open)
                {
                    _connection.Open();
                }

                DmCommand command = new DmCommand(strSQL, _connection);
                result = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw new Exception("数据库操作失败: " + ex.Message);
            }
            finally
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                }
            }

            return result;
        }

        public static void AddProjectMember(string connectionString, int projectId, int providedGroupId, string memberName, string position, string status)
        {
            using (var conn = new DmConnection(connectionString))
            {
                conn.Open();
                using (var tran = conn.BeginTransaction() as DmTransaction)
                {
                    int groupId = providedGroupId;
                    if (groupId == 0) // 需要创建默认分组
                    {
                        using (var cmd = new DmCommand("insert into ZRLDATABASE.\"GROUPS\" (name) values('默认分组')", conn))
                        {
                            cmd.Transaction = tran;
                            cmd.ExecuteNonQuery();
                        }
                        using (var cmd = new DmCommand("select IDENTITY_VAL_LOCAL() as id", conn))
                        {
                            cmd.Transaction = tran;
                            groupId = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                    }

                    using (var cmd = new DmCommand("insert into ZRLDATABASE.PROJECT_MEMBERS (project_id, group_id, member_name, position, member_status) values(?, ?, ?, ?, ?)", conn))
                    {
                        cmd.Transaction = tran;
                        cmd.Parameters.Add(new DmParameter("?", projectId));
                        cmd.Parameters.Add(new DmParameter("?", groupId));
                        cmd.Parameters.Add(new DmParameter("?", memberName));
                        cmd.Parameters.Add(new DmParameter("?", position));
                        cmd.Parameters.Add(new DmParameter("?", status));
                        cmd.ExecuteNonQuery();
                    }
                    tran.Commit();
                }
            }
        }
    }
}