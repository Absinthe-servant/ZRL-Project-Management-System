﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using OfficeOpenXml;
using System;
using System.Data;
using System.IO;
using ZRL_Employee_Info_Sys.Helpers;

namespace ZRL_Employee_Info_Sys.Controllers
{
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        string strSQL = "";

        [HttpGet("getGroups")]
        public string GetGroups()
        {
            // 查询所有分组
            strSQL = string.Format(@"select id, name from ZRLDATABASE.""GROUPS"" order by name");
            
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            string json = dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "null";
            return json;
        }

        [HttpGet("getByName")]
        public string GetByName(string v_Name)
        {
            // 根据成员名查询项目成员信息
            strSQL = string.Format(@"select pm.*, g.name as group_name from ZRLDATABASE.PROJECT_MEMBERS pm left join ZRLDATABASE.""GROUPS"" g on pm.group_id = g.id where pm.member_name='{0}'", v_Name);
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            string json = dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "null";
            return json;
        }

        [HttpGet("getProjectMembers")]
        public string GetProjectMembers(string v_ProjectId)
        {
            // 关联查询项目成员信息，包含职位和状态
            strSQL = string.Format(@"select 
                pm.id as member_id,
                pm.project_id,
                pm.group_id,
                g.name as group_name,
                pm.member_name,
                pm.position,
                pm.member_status
            from 
                ZRLDATABASE.PROJECT_MEMBERS pm
            left join 
                ZRLDATABASE.""GROUPS"" g on pm.group_id = g.id
            where 
                pm.project_id = '{0}'", v_ProjectId);
            
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            // 无数据时返回 "null"
            string json = dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "null";
            return json;
        }

        [HttpGet("getProjects")]
        public string GetProjects()
        {
            // 查询所有项目，按项目名称排序
            strSQL = string.Format(@"select 
                id, 
                name as project_name,
                description,
                status,
                create_time
            from 
                ZRLDATABASE.PROJECTS 
            order by 
                name");
            
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            string json = dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "[]";
            return json;
        }

        [HttpGet("updateMemberStatus")]
        public void UpdateMemberStatus(string v_MemberId, string v_Status)
        {
            // 更新项目成员的状态
            strSQL = string.Format(@"update 
                ZRLDATABASE.PROJECT_MEMBERS 
            set 
                member_status = '{0}' 
            where 
                id = '{1}'", v_Status, v_MemberId);
            
            DBHelper.ExecuteNonQuery(strSQL);
        }

        [HttpGet("saveProjectMember")]
        public IActionResult SaveProjectMember(string v_Id, string v_ProjectId, string v_GroupId, string v_MemberName, string v_Position, string v_Status)
        {
            try
            {
                // 验证项目ID
                if (string.IsNullOrEmpty(v_ProjectId) || v_ProjectId == "0")
                {
                    return Json(new { success = false, message = "请选择项目" });
                }

                // 验证成员姓名
                if (string.IsNullOrEmpty(v_MemberName))
                {
                    return Json(new { success = false, message = "成员姓名不能为空" });
                }

                int projectId = int.Parse(v_ProjectId);
                int? groupId = null;
                string position = v_Position?.Trim();

                // 智能分组处理：根据职位自动获取或创建分组
                if (!string.IsNullOrEmpty(position))
                {
                    // 根据职位名称搜索相似分组
                    string searchGroupSql = $@"
                SELECT ID, NAME 
                FROM ZRLDATABASE.""GROUPS"" 
                WHERE NAME LIKE '%{position.Replace("'", "''")}%' 
                OR '{position.Replace("'", "''")}' LIKE '%' || NAME || '%'
                ORDER BY LENGTH(NAME) DESC";

                    DataTable groupDt = DBHelper.Query(searchGroupSql).Tables[0];

                    if (groupDt.Rows.Count > 0)
                    {
                        // 使用第一个匹配的分组
                        groupId = Convert.ToInt32(groupDt.Rows[0]["ID"]);
                    }
                    else
                    {
                        // 如果没有找到匹配的分组，创建新分组
                        string insertGroupSql = $@"
                    INSERT INTO ZRLDATABASE.""GROUPS"" (NAME) 
                    VALUES ('{position.Replace("'", "''")}')";

                        DBHelper.ExecuteNonQuery(insertGroupSql);

                        // 获取新分组ID（达梦数据库语法）
                        string getNewIdSql = "SELECT IDENTITY_VAL_LOCAL() as id";
                        DataTable newGroupDt = DBHelper.Query(getNewIdSql).Tables[0];

                        if (newGroupDt.Rows.Count > 0)
                        {
                            groupId = Convert.ToInt32(newGroupDt.Rows[0]["id"]);
                        }
                    }
                }

                // 验证项目是否存在
                string checkProjectSql = $"SELECT COUNT(*) FROM ZRLDATABASE.PROJECTS WHERE ID = {projectId}";
                int projectExists = Convert.ToInt32(DBHelper.ExecuteScalar(checkProjectSql));

                if (projectExists == 0)
                {
                    return Json(new { success = false, message = $"项目ID {projectId} 不存在" });
                }

                // 准备SQL参数
                string groupIdValue = groupId.HasValue ? groupId.Value.ToString() : "NULL";
                string statusValue = !string.IsNullOrEmpty(v_Status) ? v_Status : "1";

                string strSQL;
                if (v_Id == "null" || string.IsNullOrEmpty(v_Id))
                {
                    // 插入新成员
                    strSQL = $@"
                INSERT INTO ZRLDATABASE.PROJECT_MEMBERS 
                (PROJECT_ID, GROUP_ID, MEMBER_NAME, POSITION, MEMBER_STATUS) 
                VALUES 
                ({projectId}, {groupIdValue}, '{v_MemberName.Replace("'", "''")}', 
                 '{position.Replace("'", "''")}', {statusValue})";
                }
                else
                {
                    // 更新现有成员
                    int memberId = int.Parse(v_Id);
                    strSQL = $@"
                UPDATE ZRLDATABASE.PROJECT_MEMBERS 
                SET PROJECT_ID = {projectId}, 
                    GROUP_ID = {groupIdValue}, 
                    MEMBER_NAME = '{v_MemberName.Replace("'", "''")}', 
                    POSITION = '{position.Replace("'", "''")}', 
                    MEMBER_STATUS = {statusValue}
                WHERE ID = {memberId}";
                }

                DBHelper.ExecuteNonQuery(strSQL);
                return Json(new { success = true, message = "保存成功" });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    message = $"保存失败: {ex.Message}",
                    details = ex.InnerException?.Message
                });
            }
        }

        [HttpGet("searchGroups")]
        public string SearchGroups(string keyword)
        {
            try
            {
                if (string.IsNullOrEmpty(keyword))
                {
                    return "[]";
                }

                string sql = $@"
            SELECT ID, NAME 
            FROM ZRLDATABASE.""GROUPS"" 
            WHERE NAME LIKE '%{keyword.Replace("'", "''")}%'
            ORDER BY 
                CASE WHEN NAME = '{keyword.Replace("'", "''")}' THEN 0
                     WHEN NAME LIKE '{keyword.Replace("'", "''")}%' THEN 1
                     ELSE 2
                END,
                LENGTH(NAME),
                NAME
            LIMIT 20";

                DataTable dt = DBHelper.Query(sql).Tables[0];
                return dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "[]";
            }
            catch (Exception)
            {
                return "[]";
            }
        }

        [HttpGet("getMemberById")]
        public string GetMemberById(int id)
        {
            try
            {
                string sql = $@"
            SELECT 
                pm.ID,
                pm.PROJECT_ID,
                pm.MEMBER_NAME as name,
                pm.POSITION as role,
                pm.MEMBER_STATUS as status,
                pm.PHONE,
                pm.ADDRESS,
                pm.JOIN_DATE,
                g.NAME as group_name,
                p.NAME as project_name
            FROM ZRLDATABASE.PROJECT_MEMBERS pm
            LEFT JOIN ZRLDATABASE.""GROUPS"" g ON pm.GROUP_ID = g.ID
            LEFT JOIN ZRLDATABASE.PROJECTS p ON pm.PROJECT_ID = p.ID
            WHERE pm.ID = {id}";

                DataTable dt = DBHelper.Query(sql).Tables[0];
                return dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "null";
            }
            catch (Exception)
            {
                return "null";
            }
        }

        [HttpGet("getTree")]
        public string GetTree(string v_ProjectName)
        {
            try
            {
                if (string.IsNullOrEmpty(v_ProjectName))
                {
                    return "[]";
                }

                // 获取项目ID
                string projectSql = $@"
            SELECT ID, NAME 
            FROM ZRLDATABASE.PROJECTS 
            WHERE NAME = '{v_ProjectName.Replace("'", "''")}'";

                DataTable projectDt = DBHelper.Query(projectSql).Tables[0];

                if (projectDt.Rows.Count == 0)
                {
                    return "[]";
                }

                int projectId = Convert.ToInt32(projectDt.Rows[0]["ID"]);
                string projectName = projectDt.Rows[0]["NAME"].ToString();

                // 获取项目成员并按职位分组
                string membersSql = $@"
            SELECT 
                pm.ID,
                pm.MEMBER_NAME,
                pm.POSITION,
                pm.MEMBER_STATUS,
                g.NAME as GROUP_NAME
            FROM ZRLDATABASE.PROJECT_MEMBERS pm
            LEFT JOIN ZRLDATABASE.""GROUPS"" g ON pm.GROUP_ID = g.ID
            WHERE pm.PROJECT_ID = {projectId}
            ORDER BY pm.POSITION, pm.MEMBER_NAME";

                DataTable membersDt = DBHelper.Query(membersSql).Tables[0];

                // 构建树形结构
                List<dynamic> treeNodes = new List<dynamic>();

                // 项目根节点
                var projectNode = new
                {
                    id = $"project_{projectId}",
                    text = projectName,
                    state = "closed",
                    iconCls = "icon-project",
                    attributes = new { type = "project" },
                    children = new List<dynamic>()
                };

                // 按职位分组
                var positionGroups = membersDt.AsEnumerable()
                    .GroupBy(row => row["POSITION"]?.ToString() ?? "未分组")
                    .OrderBy(g => g.Key);

                foreach (var positionGroup in positionGroups)
                {
                    string position = positionGroup.Key;

                    var positionNode = new
                    {
                        id = $"position_{projectId}_{position.GetHashCode()}",
                        text = $"{position} ({positionGroup.Count()})",
                        state = "closed",
                        iconCls = "icon-position",
                        attributes = new { type = "position" },
                        children = new List<dynamic>()
                    };

                    foreach (DataRow memberRow in positionGroup)
                    {
                        string memberId = memberRow["ID"].ToString();
                        string memberName = memberRow["MEMBER_NAME"].ToString();
                        string memberStatus = memberRow["MEMBER_STATUS"].ToString();

                        var memberNode = new
                        {
                            id = $"member_{memberId}",
                            text = $"{memberName} (状态: {GetStatusText(memberStatus)})",
                            state = "open",
                            iconCls = "icon-member",
                            attributes = new
                            {
                                type = "member",
                                memberId = memberId,
                                status = memberStatus
                            }
                        };

                        positionNode.children.Add(memberNode);
                    }

                    projectNode.children.Add(positionNode);
                }

                treeNodes.Add(projectNode);

                return Newtonsoft.Json.JsonConvert.SerializeObject(treeNodes);
            }
            catch
            {
                return "[]";
            }
        }

        [HttpPost("initDatabase")]
        public IActionResult InitDatabase()
        {
            try
            {
                // 1. 插入分组数据
                string insertGroupsSql = @"
            INSERT INTO ZRLDATABASE.""GROUPS"" (NAME) 
            SELECT '开发组' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.""GROUPS"" WHERE NAME='开发组')
            UNION ALL
            SELECT '测试组' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.""GROUPS"" WHERE NAME='测试组')
            UNION ALL
            SELECT '设计组' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.""GROUPS"" WHERE NAME='设计组')
            UNION ALL
            SELECT '项目管理组' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.""GROUPS"" WHERE NAME='项目管理组')";

                DBHelper.ExecuteNonQuery(insertGroupsSql);

                // 2. 插入项目数据
                string insertProjectsSql = @"
            INSERT INTO ZRLDATABASE.PROJECTS (NAME, DESCRIPTION, STATUS) 
            SELECT 'ZRL数字化平台', '中石化ZRL项目数字化管理平台建设', 2 FROM DUAL 
            WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.PROJECTS WHERE NAME='ZRL数字化平台')
            UNION ALL
            SELECT 'ERP系统升级', '企业资源计划系统升级项目', 2 FROM DUAL 
            WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.PROJECTS WHERE NAME='ERP系统升级')
            UNION ALL
            SELECT '安全防护体系', '网络安全防护体系建设', 1 FROM DUAL 
            WHERE NOT EXISTS (SELECT 1 FROM ZRLDATABASE.PROJECTS WHERE NAME='安全防护体系')";

                DBHelper.ExecuteNonQuery(insertProjectsSql);

                // 3. 检查是否已有成员数据
                string checkMembersSql = "SELECT COUNT(*) FROM ZRLDATABASE.PROJECT_MEMBERS";
                int memberCount = Convert.ToInt32(DBHelper.ExecuteScalar(checkMembersSql));

                if (memberCount == 0)
                {
                    // 4. 插入项目成员数据
                    string insertMembersSql = @"
                INSERT INTO ZRLDATABASE.PROJECT_MEMBERS (PROJECT_ID, GROUP_ID, MEMBER_NAME, POSITION, MEMBER_STATUS)
                SELECT p.ID, g.ID, '张三', '项目经理', 1
                FROM ZRLDATABASE.PROJECTS p, ZRLDATABASE.""GROUPS"" g
                WHERE p.NAME = 'ZRL数字化平台' AND g.NAME = '项目管理组'
                UNION ALL
                SELECT p.ID, g.ID, '李四', '后端开发工程师', 2
                FROM ZRLDATABASE.PROJECTS p, ZRLDATABASE.""GROUPS"" g
                WHERE p.NAME = 'ZRL数字化平台' AND g.NAME = '开发组'";

                    DBHelper.ExecuteNonQuery(insertMembersSql);
                }

                // 5. 获取统计信息
                string countSql = @"
            SELECT 
                '项目表' AS 表名, COUNT(*) AS 记录数 FROM ZRLDATABASE.PROJECTS
            UNION ALL
            SELECT '分组表', COUNT(*) FROM ZRLDATABASE.""GROUPS""
            UNION ALL
            SELECT '项目成员表', COUNT(*) FROM ZRLDATABASE.PROJECT_MEMBERS";

                DataTable dt = DBHelper.Query(countSql).Tables[0];

                return Json(new
                {
                    success = true,
                    message = "数据库初始化成功！",
                    data = dt
                });
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    message = $"数据库初始化失败: {ex.Message}"
                });
            }
        }

        private string GetStatusText(string status)
        {
            switch (status)
            {
                case "1": return "待分配";
                case "2": return "进行中";
                case "3": return "已完成";
                default: return "未知";
            }
        }

        [HttpGet("saveProject")]
        public void SaveProject(string v_Id, string v_Name, string v_Description, string v_Status)
        {
            if (v_Id == "null")
                strSQL = string.Format(@"insert into ZRLDATABASE.PROJECTS (name, description, status, create_time) values('{0}','{1}','{2}',NOW())", 
                    v_Name, v_Description, v_Status);
            else
                strSQL = string.Format(@"update ZRLDATABASE.PROJECTS set name='{0}',description='{1}',status='{2}' where id={3}", 
                    v_Name, v_Description, v_Status, v_Id);
            DBHelper.ExecuteNonQuery(strSQL);
        }

        [HttpGet("delProjectMember")]
        public IActionResult DelProjectMember(string v_id)
        {
            try
            {
                // 验证参数
                if (string.IsNullOrEmpty(v_id) || v_id == "null")
                {
                    return Json(new { success = false, message = "参数错误：成员ID不能为空" });
                }

                // 达梦数据库的安全删除语法
                strSQL = $"DELETE FROM ZRLDATABASE.PROJECT_MEMBERS WHERE ID = {v_id}";

                int affectedRows = DBHelper.ExecuteNonQuery(strSQL);

                if (affectedRows > 0)
                {
                    return Json(new { success = true, message = "删除成功" });
                }
                else
                {
                    return Json(new { success = false, message = "删除失败：未找到该成员" });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"删除成员错误: {ex.Message}");
                return Json(new
                {
                    success = false,
                    message = $"删除失败: {ex.Message}",
                    details = ex.InnerException?.Message
                });
            }
        }

        [HttpGet("delProject")]
        public void DelProject(string v_id)
        {
            strSQL = string.Format(@"delete from ZRLDATABASE.PROJECT_MEMBERS where project_id={0}", v_id);
            DBHelper.ExecuteNonQuery(strSQL);
            strSQL = string.Format(@"delete from ZRLDATABASE.PROJECTS where id={0}", v_id);
            DBHelper.ExecuteNonQuery(strSQL);
        }

        [HttpGet("getProjectByName")]
        public string GetProjectByName(string v_Name)
        {
            try
            {
                if (string.IsNullOrEmpty(v_Name))
                {
                    return "null";
                }

                // 查询项目基本信息
                string projectSql = $@"
        SELECT 
            p.id,
            p.name as project_name,
            p.description,
            p.status as project_status,
            p.create_time
        FROM 
            ZRLDATABASE.PROJECTS p
        WHERE 
            p.name = '{v_Name.Replace("'", "''")}'";  // 改为精确匹配

                DataTable projectDt = DBHelper.Query(projectSql).Tables[0];

                if (projectDt.Rows.Count == 0)
                {
                    // 如果没有精确匹配，尝试模糊匹配
                    projectSql = $@"
            SELECT 
                p.id,
                p.name as project_name,
                p.description,
                p.status as project_status,
                p.create_time
            FROM 
                ZRLDATABASE.PROJECTS p
            WHERE 
                p.name LIKE '%{v_Name.Replace("'", "''")}%'
            ORDER BY 
                p.name";

                    projectDt = DBHelper.Query(projectSql).Tables[0];

                    if (projectDt.Rows.Count == 0)
                    {
                        return "null";
                    }
                }

                // 获取第一个项目的信息
                DataRow projectRow = projectDt.Rows[0];
                int projectId = Convert.ToInt32(projectRow["id"]);

                var result = new Dictionary<string, object>
        {
            { "id", projectId },
            { "project_name", projectRow["project_name"] },
            { "description", projectRow["description"] },
            { "project_status", projectRow["project_status"] },
            { "create_time", projectRow["create_time"].ToString() }
        };

                // 查询项目成员 - 修正字段映射
                string membersSql = $@"
        SELECT 
            pm.ID as member_id,
            pm.MEMBER_NAME as member_name,
            pm.POSITION as position,
            pm.MEMBER_STATUS as member_status,
            g.NAME as group_name
        FROM 
            ZRLDATABASE.PROJECT_MEMBERS pm
        LEFT JOIN 
            ZRLDATABASE.""GROUPS"" g ON pm.GROUP_ID = g.ID
        WHERE 
            pm.PROJECT_ID = {projectId}
        ORDER BY 
            pm.MEMBER_NAME";

                DataTable membersDt = DBHelper.Query(membersSql).Tables[0];

                // 将成员信息转换为列表
                var members = new List<Dictionary<string, object>>();
                foreach (DataRow memberRow in membersDt.Rows)
                {
                    var member = new Dictionary<string, object>
            {
                { "member_id", memberRow["member_id"] },
                { "member_name", memberRow["member_name"]?.ToString() ?? "" },
                { "position", memberRow["position"]?.ToString() ?? "" },
                { "member_status", memberRow["member_status"]?.ToString() ?? "1" },
                { "group_name", memberRow["group_name"]?.ToString() ?? "" }
            };
                    members.Add(member);
                }

                result.Add("members", members);

                // 使用 CreateJson 转换为 JSON
                return CreateJson.ToJson(result);
            }
            catch (Exception ex)
            {
                // 返回更详细的错误信息用于调试
                var errorResult = new Dictionary<string, object>
        {
            { "error", true },
            { "message", "查询项目失败: " + ex.Message },
            { "members", new List<object>() }
        };
                return CreateJson.ToJson(errorResult);
            }
        }

        [HttpGet("saveGroup")]
        public string SaveGroup(string v_Name)
        {
            // 保存分组（如果不存在则新建）
            strSQL = string.Format(@"insert into ZRLDATABASE.""GROUPS"" (name) values ('{0}')", v_Name);
            DBHelper.ExecuteNonQuery(strSQL);
            
            // 获取新插入的分组ID（达梦数据库语法）
            strSQL = "select IDENTITY_VAL_LOCAL() as id";
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            int newGroupId = dt.Rows.Count > 0 ? Convert.ToInt32(dt.Rows[0]["id"]) : 0;
            
            // 返回新分组ID的JSON格式
            return "{\"id\":\"" + newGroupId + "\"}";
        }

        [HttpGet("getGroupByName")]
        public string GetGroupByName(string v_Name)
        {
            // 按分组名查询分组（用于自动补全）
            strSQL = string.Format(@"select id, name from ZRLDATABASE.""GROUPS"" where name like '%{0}%' order by name", v_Name);
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            string json = dt.Rows.Count > 0 ? CreateJson.ToJson(dt) : "null";
            return json;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadFile(IFormFile fileInput)
        {
            if (fileInput != null && fileInput.Length > 0)
            {
                Guid id = Guid.NewGuid();
                var fileName = id + "_" + fileInput.FileName;
                var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);

                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await fileInput.CopyToAsync(stream);
                }
                return Json(new { success = true, message = fileName });
            }
            return Json(new { success = false, message = "No file uploaded" });
        }

        //数据导入
        [HttpPost("import")]
        public IActionResult Import()
        {
            try
            {
                var formFile = Request.Form.Files[0];

                if (formFile.FileName == "")
                    return Json(new { success = false, message = "noFile" });

                ExcelPackage.License.SetNonCommercialPersonal("XSK");
                using (var package = new ExcelPackage(formFile.OpenReadStream()))
                {
                    var workbook = package.Workbook;
                    var worksheet = workbook.Worksheets[0];

                    for (var i = 2; i < worksheet.Dimension.End.Row + 1; i++)
                    {
                        if (worksheet.Cells[i, 2].Value == null)
                            break;
                        
                        string projectName = worksheet.Cells[i, 2].Value?.ToString();
                        string memberName = worksheet.Cells[i, 3].Value?.ToString();
                        string position = worksheet.Cells[i, 4].Value?.ToString();
                        string status = worksheet.Cells[i, 5].Value?.ToString();
                        string groupName = worksheet.Cells[i, 6].Value?.ToString();

                        string projectQuery = string.Format(@"select id from ZRLDATABASE.PROJECTS where name='{0}'", projectName);
                        DataTable projectDt = DBHelper.Query(projectQuery).Tables[0];
                        int projectId = 0;
                        if (projectDt.Rows.Count > 0)
                        {
                            projectId = Convert.ToInt32(projectDt.Rows[0]["id"]);
                        }
                        else
                        {
                            string insertProject = string.Format(@"insert into ZRLDATABASE.PROJECTS (name, description, status, create_time) values ('{0}','',1,NOW())", projectName);
                            DBHelper.ExecuteNonQuery(insertProject);
                            projectDt = DBHelper.Query(projectQuery).Tables[0];
                            if (projectDt.Rows.Count > 0)
                            {
                                projectId = Convert.ToInt32(projectDt.Rows[0]["id"]);
                            }
                        }

                        string groupQuery = string.Format(@"select id from ZRLDATABASE.""GROUPS"" where name='{0}'", groupName);
                        DataTable groupDt = DBHelper.Query(groupQuery).Tables[0];
                        int groupId = 0;
                        if (groupDt.Rows.Count > 0)
                        {
                            groupId = Convert.ToInt32(groupDt.Rows[0]["id"]);
                        }
                        else if (!string.IsNullOrEmpty(groupName))
                        {
                            string insertGroup = string.Format(@"insert into ZRLDATABASE.""GROUPS"" (name) values ('{0}')", groupName);
                            DBHelper.ExecuteNonQuery(insertGroup);
                            groupDt = DBHelper.Query(groupQuery).Tables[0];
                            if (groupDt.Rows.Count > 0)
                            {
                                groupId = Convert.ToInt32(groupDt.Rows[0]["id"]);
                            }
                        }

                        string insertMember = string.Format(@"insert into ZRLDATABASE.PROJECT_MEMBERS (project_id, group_id, member_name, position, member_status) values ({0},{1},'{2}','{3}','{4}')", 
                            projectId, 
                            groupId > 0 ? groupId.ToString() : "null",
                            memberName,
                            position,
                            status);
                        DBHelper.ExecuteNonQuery(insertMember);
                    }
                }
                return Json(new { success = true, message = "OK" });
            }
            catch
            {
                return Json(new { success = false, message = "fail" });
            }
        }

        //数据导出
        [HttpPost("Export")]
        public IActionResult Export([FromForm] string v_data)
        {
            JArray array = JArray.Parse(v_data);

            ExcelPackage.License.SetNonCommercialPersonal("XSK");
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Sheet1");
                worksheet.Cells["A1"].Value = "序号";
                worksheet.Cells["B1"].Value = "项目名称";
                worksheet.Cells["C1"].Value = "成员姓名";
                worksheet.Cells["D1"].Value = "职位";
                worksheet.Cells["E1"].Value = "状态";
                worksheet.Cells["F1"].Value = "分组";
                worksheet.Row(1).Height = 22;

                for (int i = 0; i < array.Count; i++)
                {
                    worksheet.Cells[i + 2, 1].Value = i + 1;
                    worksheet.Cells[i + 2, 2].Value = (string?)array[i]["project_name"];
                    worksheet.Cells[i + 2, 3].Value = (string?)array[i]["member_name"];
                    worksheet.Cells[i + 2, 4].Value = (string?)array[i]["position"];
                    string status = (string?)array[i]["member_status"];
                    worksheet.Cells[i + 2, 5].Value = status == "1" ? "待分配" : (status == "2" ? "进行中" : "已完成");
                    worksheet.Cells[i + 2, 6].Value = (string?)array[i]["group_name"];
                    worksheet.Row(i + 2).Height = 22;
                }

                for (int i = 1; i < 7; i++)
                {
                    worksheet.Column(i).Width = 20;
                    worksheet.Column(i).Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                }

                package.SaveAs(new FileInfo("wwwroot/exports/project_export.xlsx"));
                return Json(new { success = true, message = "OK" });
            }
        }
    }
}