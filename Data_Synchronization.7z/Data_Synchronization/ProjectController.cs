using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using ZRL_Employee_Info_Sys.Helpers;

namespace ZRL_Employee_Info_Sys.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        string strSQL = "";

        // 获取所有项目
        [HttpGet("getProjects")]
        public ActionResult GetProjects()
        {
            strSQL = @"
                SELECT 
                    p.ID as id,
                    p.NAME as projectname,
                    p.DESCRIPTION as description,
                    p.STATUS as status,
                    p.CREATE_TIME as create_time,
                    COUNT(pm.ID) as member_count
                FROM PROJECTS p
                LEFT JOIN PROJECT_MEMBERS pm ON p.ID = pm.PROJECT_ID
                GROUP BY p.ID, p.NAME, p.DESCRIPTION, p.STATUS, p.CREATE_TIME
                ORDER BY p.CREATE_TIME DESC";

            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            return Ok(CreateJson.ToJson(dt));
        }

        // 根据项目名称获取项目及成员
        [HttpGet("getByProjectName")]
        public ActionResult GetByProjectName(string projectName)
        {
            // 获取项目信息
            strSQL = $@"
                SELECT 
                    ID, 
                    NAME as project_name, 
                    DESCRIPTION, 
                    STATUS, 
                    CREATE_TIME
                FROM PROJECTS 
                WHERE NAME = '{projectName}'";

            DataTable projectDt = DBHelper.Query(strSQL).Tables[0];
            if (projectDt.Rows.Count == 0)
            {
                return Ok(new { success = false, message = "项目不存在" });
            }

            int projectId = Convert.ToInt32(projectDt.Rows[0]["ID"]);

            // 获取项目成员信息
            strSQL = $@"
                SELECT 
                    pm.ID,
                    pm.MEMBER_NAME as name,
                    pm.POSITION as role,
                    pm.MEMBER_STATUS as status,
                    g.NAME as group_name,
                    p.PHONE as phone,
                    p.ADDRESS as address,
                    p.PHOTOPATH as photopath
                FROM PROJECT_MEMBERS pm
                LEFT JOIN [GROUPS] g ON pm.GROUP_ID = g.ID
                LEFT JOIN PERSONS p ON pm.MEMBER_NAME = p.NAME
                WHERE pm.PROJECT_ID = {projectId}
                ORDER BY pm.POSITION, pm.MEMBER_NAME";

            DataTable membersDt = DBHelper.Query(strSQL).Tables[0];

            return Ok(new
            {
                success = true,
                project = CreateJson.ToObject(projectDt.Rows[0]),
                members = CreateJson.ToList(membersDt)
            });
        }

        // 创建新项目
        [HttpPost("create")]
        public ActionResult CreateProject([FromForm] string projectname)
        {
            try
            {
                // 检查项目是否已存在
                strSQL = $"SELECT ID FROM PROJECTS WHERE NAME = '{projectname}'";
                DataTable dt = DBHelper.Query(strSQL).Tables[0];

                if (dt.Rows.Count > 0)
                {
                    return Ok(new { success = true, id = dt.Rows[0]["ID"] });
                }

                // 创建新项目
                strSQL = $"INSERT INTO PROJECTS (NAME, CREATE_TIME) VALUES ('{projectname}', GETDATE()); SELECT SCOPE_IDENTITY();";
                object result = DBHelper.ExecuteScalar(strSQL);
                int newId = Convert.ToInt32(result);

                return Ok(new { success = true, id = newId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 获取项目成员
        [HttpGet("getMembers")]
        public ActionResult GetMembers(string v_ProjectName)
        {
            strSQL = $@"
                SELECT 
                    pm.ID as id,
                    pm.MEMBER_NAME as name,
                    pm.POSITION as role,
                    pm.MEMBER_STATUS as status,
                    g.NAME as group_name,
                    p.PHONE as phone,
                    p.ADDRESS as address,
                    p.PHOTOPATH as photopath
                FROM PROJECT_MEMBERS pm
                LEFT JOIN [GROUPS] g ON pm.GROUP_ID = g.ID
                LEFT JOIN PERSONS p ON pm.MEMBER_NAME = p.NAME
                WHERE pm.PROJECT_ID IN (
                    SELECT ID FROM PROJECTS WHERE NAME = '{v_ProjectName}'
                )
                ORDER BY pm.POSITION, pm.MEMBER_NAME";

            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            return Ok(CreateJson.ToJson(dt));
        }

        // 保存项目成员（智能分组功能）
        [HttpPost("saveMember")]
        public ActionResult SaveMember(
            [FromForm] string v_Id,
            [FromForm] string v_Name,
            [FromForm] string v_Role,
            [FromForm] string v_Status,
            [FromForm] string v_Phone,
            [FromForm] string v_Address,
            [FromForm] string v_ProjectName,
            [FromForm] string v_GroupName = "")
        {
            try
            {
                // 1. 获取项目ID
                strSQL = $"SELECT ID FROM PROJECTS WHERE NAME = '{v_ProjectName}'";
                DataTable projectDt = DBHelper.Query(strSQL).Tables[0];

                if (projectDt.Rows.Count == 0)
                {
                    return BadRequest(new { success = false, message = "项目不存在" });
                }
                int projectId = Convert.ToInt32(projectDt.Rows[0]["ID"]);

                // 2. 处理分组（智能分组功能）
                int? groupId = null;
                if (!string.IsNullOrEmpty(v_GroupName))
                {
                    // 检查分组是否存在
                    strSQL = $"SELECT ID FROM [GROUPS] WHERE NAME = '{v_GroupName}'";
                    DataTable groupDt = DBHelper.Query(strSQL).Tables[0];

                    if (groupDt.Rows.Count == 0)
                    {
                        // 创建新分组
                        strSQL = $"INSERT INTO [GROUPS] (NAME) VALUES ('{v_GroupName}'); SELECT SCOPE_IDENTITY();";
                        object newGroupId = DBHelper.ExecuteScalar(strSQL);
                        groupId = Convert.ToInt32(newGroupId);
                    }
                    else
                    {
                        groupId = Convert.ToInt32(groupDt.Rows[0]["ID"]);
                    }
                }

                // 3. 保存人员信息到PERSONS表（如果需要）
                strSQL = $"SELECT ID FROM PERSONS WHERE NAME = '{v_Name}'";
                DataTable personDt = DBHelper.Query(strSQL).Tables[0];

                if (personDt.Rows.Count == 0 && (!string.IsNullOrEmpty(v_Phone) || !string.IsNullOrEmpty(v_Address)))
                {
                    strSQL = $"INSERT INTO PERSONS (NAME, PHONE, ADDRESS) VALUES ('{v_Name}', '{v_Phone}', '{v_Address}')";
                    DBHelper.ExecuteNonQuery(strSQL);
                }

                // 4. 保存项目成员信息
                if (v_Id == "null" || string.IsNullOrEmpty(v_Id))
                {
                    // 新增成员
                    string groupIdValue = groupId.HasValue ? groupId.Value.ToString() : "NULL";
                    strSQL = $@"
                        INSERT INTO PROJECT_MEMBERS 
                            (PROJECT_ID, GROUP_ID, MEMBER_NAME, POSITION, MEMBER_STATUS) 
                        VALUES 
                            ({projectId}, {groupIdValue}, '{v_Name}', '{v_Role}', {v_Status})";
                }
                else
                {
                    // 更新成员
                    string groupIdValue = groupId.HasValue ? groupId.Value.ToString() : "NULL";
                    strSQL = $@"
                        UPDATE PROJECT_MEMBERS 
                        SET MEMBER_NAME = '{v_Name}',
                            POSITION = '{v_Role}',
                            MEMBER_STATUS = {v_Status},
                            GROUP_ID = {groupIdValue}
                        WHERE ID = {v_Id}";
                }

                DBHelper.ExecuteNonQuery(strSQL);
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 删除项目成员
        [HttpPost("deleteMember")]
        public ActionResult DeleteMember([FromForm] string v_id)
        {
            try
            {
                strSQL = $"DELETE FROM PROJECT_MEMBERS WHERE ID = {v_id}";
                DBHelper.ExecuteNonQuery(strSQL);
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 获取项目树形结构
        [HttpGet("getTree")]
        public ActionResult GetTree(string v_ProjectName)
        {
            try
            {
                // 获取项目ID
                strSQL = $"SELECT ID FROM PROJECTS WHERE NAME = '{v_ProjectName}'";
                DataTable projectDt = DBHelper.Query(strSQL).Tables[0];

                if (projectDt.Rows.Count == 0)
                {
                    return Ok(new List<object>());
                }

                int projectId = Convert.ToInt32(projectDt.Rows[0]["ID"]);

                // 获取项目成员，按职位分组
                strSQL = $@"
                    SELECT 
                        pm.POSITION,
                        pm.ID as member_id,
                        pm.MEMBER_NAME,
                        pm.MEMBER_STATUS,
                        g.NAME as group_name
                    FROM PROJECT_MEMBERS pm
                    LEFT JOIN [GROUPS] g ON pm.GROUP_ID = g.ID
                    WHERE pm.PROJECT_ID = {projectId}
                    ORDER BY pm.POSITION, pm.MEMBER_NAME";

                DataTable membersDt = DBHelper.Query(strSQL).Tables[0];

                // 构建树形结构
                var positions = membersDt.AsEnumerable()
                    .GroupBy(row => row["POSITION"].ToString())
                    .Select(g => new
                    {
                        id = $"pos_{g.Key}",
                        text = g.Key + $" ({g.Count()}人)",
                        children = g.Select(m => new
                        {
                            id = m["member_id"].ToString(),
                            text = m["MEMBER_NAME"].ToString(),
                            attributes = new
                            {
                                type = "member",
                                status = m["MEMBER_STATUS"].ToString(),
                                role = g.Key,
                                group = m["group_name"].ToString()
                            }
                        }).ToList()
                    }).ToList();

                var tree = new
                {
                    id = projectId.ToString(),
                    text = v_ProjectName,
                    state = "open",
                    children = positions
                };

                return Ok(new[] { tree });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 智能分组查询（用于combobox自动完成）
        [HttpGet("searchGroups")]
        public ActionResult SearchGroups(string keyword)
        {
            try
            {
                if (string.IsNullOrEmpty(keyword))
                {
                    // 返回所有分组
                    strSQL = "SELECT ID as id, NAME as text FROM [GROUPS] ORDER BY NAME";
                }
                else
                {
                    // 模糊查询
                    strSQL = $"SELECT ID as id, NAME as text FROM [GROUPS] WHERE NAME LIKE '%{keyword}%' ORDER BY NAME";
                }

                DataTable dt = DBHelper.Query(strSQL).Tables[0];
                return Ok(CreateJson.ToJson(dt));
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 上传成员照片
        [HttpPost("uploadMemberPhoto")]
        public async Task<IActionResult> UploadMemberPhoto([FromForm] int memberId, IFormFile fileInput)
        {
            if (fileInput == null || fileInput.Length == 0)
                return BadRequest(new { success = false, message = "没有上传文件" });

            try
            {
                // 获取成员姓名
                strSQL = $"SELECT MEMBER_NAME FROM PROJECT_MEMBERS WHERE ID = {memberId}";
                DataTable dt = DBHelper.Query(strSQL).Tables[0];

                if (dt.Rows.Count == 0)
                    return BadRequest(new { success = false, message = "成员不存在" });

                string memberName = dt.Rows[0]["MEMBER_NAME"].ToString();

                // 生成文件名
                string fileName = $"{memberId}_{DateTime.Now:yyyyMMddHHmmss}{Path.GetExtension(fileInput.FileName)}";
                string uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", fileName);

                // 保存文件
                using (var stream = new FileStream(uploadPath, FileMode.Create))
                {
                    await fileInput.CopyToAsync(stream);
                }

                // 更新PERSONS表中的照片路径
                strSQL = $@"
                    IF EXISTS (SELECT 1 FROM PERSONS WHERE NAME = '{memberName}')
                    BEGIN
                        UPDATE PERSONS SET PHOTOPATH = '{fileName}' WHERE NAME = '{memberName}'
                    END
                    ELSE
                    BEGIN
                        INSERT INTO PERSONS (NAME, PHOTOPATH) VALUES ('{memberName}', '{fileName}')
                    END";

                DBHelper.ExecuteNonQuery(strSQL);

                return Ok(new { success = true, fileName = fileName });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 根据ID获取成员信息
        [HttpGet("getMemberById")]
        public ActionResult GetMemberById(int id)
        {
            try
            {
                strSQL = $@"
                    SELECT 
                        pm.ID,
                        pm.MEMBER_NAME as name,
                        pm.POSITION as role,
                        pm.MEMBER_STATUS as status,
                        g.NAME as group_name,
                        p.PHONE as phone,
                        p.ADDRESS as address,
                        p.PHOTOPATH as photopath
                    FROM PROJECT_MEMBERS pm
                    LEFT JOIN [GROUPS] g ON pm.GROUP_ID = g.ID
                    LEFT JOIN PERSONS p ON pm.MEMBER_NAME = p.NAME
                    WHERE pm.ID = {id}";

                DataTable dt = DBHelper.Query(strSQL).Tables[0];

                if (dt.Rows.Count == 0)
                    return Ok(new { });

                return Ok(CreateJson.ToObject(dt.Rows[0]));
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 在ProjectController中添加分组管理方法
        [HttpPost("createGroup")]
        public ActionResult CreateGroup([FromForm] string groupName)
        {
            try
            {
                if (string.IsNullOrEmpty(groupName))
                {
                    return BadRequest(new { success = false, message = "分组名称不能为空" });
                }

                // 检查分组是否已存在
                strSQL = $"SELECT ID FROM [GROUPS] WHERE NAME = '{groupName}'";
                DataTable dt = DBHelper.Query(strSQL).Tables[0];

                if (dt.Rows.Count > 0)
                {
                    return Ok(new
                    {
                        success = true,
                        id = dt.Rows[0]["ID"],
                        text = groupName,
                        message = "分组已存在"
                    });
                }

                // 创建新分组
                strSQL = $"INSERT INTO [GROUPS] (NAME) VALUES ('{groupName}'); SELECT SCOPE_IDENTITY();";
                object result = DBHelper.ExecuteScalar(strSQL);
                int newId = Convert.ToInt32(result);

                return Ok(new
                {
                    success = true,
                    id = newId,
                    text = groupName,
                    message = "分组创建成功"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // 获取所有分组
        [HttpGet("getAllGroups")]
        public ActionResult GetAllGroups()
        {
            strSQL = "SELECT ID as id, NAME as text FROM [GROUPS] ORDER BY NAME";
            DataTable dt = DBHelper.Query(strSQL).Tables[0];
            return Ok(CreateJson.ToJson(dt));
        }
    }
}